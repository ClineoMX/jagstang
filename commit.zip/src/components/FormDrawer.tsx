import React from 'react';
import {
  Box,
  Button,
  Drawer,
  DrawerBody,
  DrawerContent,
  DrawerFooter,
  DrawerHeader,
  DrawerOverlay,
  HStack,
  Heading,
  Text,
  useColorModeValue,
} from '@chakra-ui/react';

export type FormDrawerSize = 'sm' | 'md' | 'lg' | 'xl' | 'split';

interface FormDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  /** Mono overline above the title. Examples: "Pacientes", "Agenda". */
  crumb?: React.ReactNode;
  /** Main drawer title (h1-equivalent). */
  title: React.ReactNode;
  /** Optional secondary line under the title. */
  sub?: React.ReactNode;
  /** Drawer width. Defaults to "md". */
  size?: FormDrawerSize;
  /**
   * Overrides the content max-width (e.g. "460px"). Combined with
   * `animateWidth`, lets the drawer grow/shrink smoothly between layouts.
   */
  contentMaxW?: string;
  /** Animate changes to the content width (max-width transition). */
  animateWidth?: boolean;
  /** Submit button label. Defaults to "Guardar". */
  submitLabel?: string;
  /** Loading state for the submit button; disables Cancel too. */
  isSubmitting?: boolean;
  /** Text shown on submit button while loading. Defaults to "Guardando…". */
  submitLoadingText?: string;
  /** Disable submit (e.g. validation not met). */
  isSubmitDisabled?: boolean;
  /** Custom cancel label. Defaults to "Cancelar". */
  cancelLabel?: string;
  /** Extra actions to show on the left side of the footer. */
  footerLeft?: React.ReactNode;
  /** Render without the built-in submit/cancel buttons. */
  hideDefaultActions?: boolean;
  /**
   * When true, the drawer body fills remaining viewport height (flex column,
   * overflow hidden). Children should set flex={1} minH={0} and their own
   * overflowY where scrolling is needed.
   */
  bodyFillHeight?: boolean;
  /**
   * Optional. When provided, the drawer body is wrapped in a <form> element
   * and the default submit button uses type="submit". Use this for standard
   * form-submit-on-enter behavior.
   */
  onSubmit?: (e: React.FormEvent) => void;
  children: React.ReactNode;
  /** Close the drawer on Esc / overlay click. Defaults to true. */
  closeOnOverlayClick?: boolean;
  /** Initial focus ref passed through to Chakra's Drawer. */
  initialFocusRef?: React.RefObject<HTMLElement>;
}

/**
 * Prototype-styled right-side drawer for forms. Replaces the old modal pattern
 * across the app so editing/creating records feels lightweight and lets the
 * user keep the underlying page in view. Mirrors `PageHead`'s typography
 * (mono crumb + flat h1 + thin divider) so drawers feel native to the redesign.
 */
const FormDrawer: React.FC<FormDrawerProps> = ({
  isOpen,
  onClose,
  crumb,
  title,
  sub,
  size = 'md',
  contentMaxW,
  animateWidth = false,
  submitLabel = 'Guardar',
  isSubmitting = false,
  submitLoadingText = 'Guardando…',
  isSubmitDisabled = false,
  cancelLabel = 'Cancelar',
  footerLeft,
  hideDefaultActions = false,
  bodyFillHeight = false,
  onSubmit,
  children,
  closeOnOverlayClick = true,
  initialFocusRef,
}) => {
  const cardBg = useColorModeValue('white', 'paper.800');
  /** Match warm page background (prototype paper), not cool `paper.50`. */
  const bodyBg = useColorModeValue('surface.page', 'paper.900');
  const borderColor = useColorModeValue('border.subtle', 'whiteAlpha.200');
  const crumbColor = useColorModeValue('brand.600', 'brand.300');
  const subColor = useColorModeValue('paper.700', 'paper.400');

  const Form: React.ElementType = onSubmit ? 'form' : 'div';
  const flexStyle: React.CSSProperties = {
    display: 'flex',
    flexDirection: 'column',
    flex: 1,
    minHeight: 0,
  };
  const formProps: Record<string, unknown> = onSubmit
    ? { onSubmit, style: flexStyle }
    : { style: flexStyle };

  return (
    <Drawer
      isOpen={isOpen}
      onClose={onClose}
      placement="right"
      size={size}
      closeOnOverlayClick={closeOnOverlayClick}
      initialFocusRef={initialFocusRef}
    >
      <DrawerOverlay bg="blackAlpha.400" />
      <DrawerContent
        bg={cardBg}
        borderLeft="1px solid"
        borderColor={borderColor}
        display="flex"
        flexDirection="column"
        maxH="100vh"
        minH={bodyFillHeight ? '100dvh' : undefined}
        maxW={contentMaxW ?? (size === 'split' ? '880px' : undefined)}
        w={contentMaxW || size === 'split' ? '100%' : undefined}
        transition={
          animateWidth
            ? 'max-width 0.35s cubic-bezier(0.4, 0, 0.2, 1)'
            : undefined
        }
      >
        <DrawerHeader
          px={6}
          pt={6}
          pb={4}
          borderBottom="1px solid"
          borderColor={borderColor}
        >
          <Box>
            {crumb && (
              <Text
                as="p"
                fontFamily="mono"
                fontSize="11px"
                color={crumbColor}
                letterSpacing="0.08em"
                textTransform="uppercase"
                mb={2}
                fontWeight={500}
              >
                {crumb}
              </Text>
            )}
            <Heading
              as="h2"
              fontSize="22px"
              fontWeight={600}
              letterSpacing="-0.015em"
              lineHeight="1.25"
              mb={sub ? 1 : 0}
            >
              {title}
            </Heading>
            {sub && (
              <Text fontSize="13px" color={subColor} mt={1} fontWeight={400}>
                {sub}
              </Text>
            )}
          </Box>
        </DrawerHeader>

        <Form {...formProps}>
          <DrawerBody
            px={6}
            py={5}
            flex={1}
            minH={0}
            bg={bodyBg}
            overflowY={bodyFillHeight ? 'hidden' : 'auto'}
            overflow={bodyFillHeight ? 'hidden' : undefined}
            display={bodyFillHeight ? 'flex' : undefined}
            flexDirection={bodyFillHeight ? 'column' : undefined}
          >
            {children}
          </DrawerBody>

          {!hideDefaultActions && (
            <DrawerFooter
              px={6}
              py={4}
              borderTop="1px solid"
              borderColor={borderColor}
              bg={cardBg}
            >
              <HStack justify="space-between" w="full">
                <Box>{footerLeft}</Box>
                <HStack spacing={2}>
                  <Button
                    variant="outline"
                    size="sm"
                    h="36px"
                    borderColor="border.default"
                    color="text.strong"
                    bg={cardBg}
                    _hover={{ borderColor: 'border.strong' }}
                    onClick={onClose}
                    isDisabled={isSubmitting}
                  >
                    {cancelLabel}
                  </Button>
                  <Button
                    type={onSubmit ? 'submit' : 'button'}
                    size="sm"
                    h="36px"
                    colorScheme="brand"
                    bg="brand.600"
                    color="white"
                    _hover={{ bg: 'brand.700' }}
                    isLoading={isSubmitting}
                    loadingText={submitLoadingText}
                    isDisabled={isSubmitDisabled}
                    onClick={!onSubmit ? undefined : undefined}
                  >
                    {submitLabel}
                  </Button>
                </HStack>
              </HStack>
            </DrawerFooter>
          )}
        </Form>
      </DrawerContent>
    </Drawer>
  );
};

export default FormDrawer;
